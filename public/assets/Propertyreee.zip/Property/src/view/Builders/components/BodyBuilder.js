import React from 'react'
import CardBuilder from './CardBuilder'

const BodyBuilder = () => {
    return (
        <div className='m-4 grid grid-cols-4 gap-2'>
            <CardBuilder />

        </div>
    )
}

export default BodyBuilder