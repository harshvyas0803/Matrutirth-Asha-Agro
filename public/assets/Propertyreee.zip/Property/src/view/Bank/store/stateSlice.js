import { createSlice } from "@reduxjs/toolkit";

const stateSlice = createSlice({
    name: "bankList/state",
    initialState: {
        deleteConfirmation: false,
        selectedBank: "",
        newDialog: false,
        filterDialog: false,
    },
    reducers: {
        toggleDeleteConfirmation: (state, action) => {
            state.deleteConfirmation = action.payload;
        },
        setSelectedBank: (state, action) => {
            state.selectedBank = action.payload;
        },
        toggleNewDialog: (state, action) => {
            state.newDialog = action.payload;
        },
        toggleFilterDialog: (state, action) => {
            state.filterDialog = action.payload;
        },
    },
});

export const {
    toggleDeleteConfirmation,
    setSelectedBank,
    toggleNewDialog,
    toggleFilterDialog,
} = stateSlice.actions;

export default stateSlice.reducer;
