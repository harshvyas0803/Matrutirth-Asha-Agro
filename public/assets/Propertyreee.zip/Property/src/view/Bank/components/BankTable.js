import React, { useEffect } from "react";
import { Table, Switch } from "antd";
import { MdEdit, MdDelete } from "react-icons/md";
import { useSelector, useDispatch } from "react-redux";
import { getBank, updateBank, deleteBank, setTableData } from "../store/dataSlice";
import { setSelectedBank, toggleNewDialog } from "../store/stateSlice";

const BankTable = ({ handleRefresh }) => {
  const dispatch = useDispatch();

  const tableData = useSelector((state) => state.bank.data.tableData);
  const { pageIndex = 1, pageSize = 10 } = tableData || {};

  const fetchData = () => {
    dispatch(getBank({ pageIndex, pageSize }));
  };

  useEffect(() => {
    fetchData();
  }, [pageIndex, pageSize, handleRefresh]);

  const data = useSelector((state) => state.bank.data.bankList?.payload);
  
  const onEdit = (record) => {
    console.log("This is record", record);
    const bankID = record._id; // Extract the builderID
    dispatch(setSelectedBank({ ...record, bankID })); // Ensure builderID is part of the selected builder
    dispatch(toggleNewDialog(true));
};

  const onDelete = async (record) => {
    console.log(record);
    await dispatch(deleteBank({ bankID: record._id })); // Call deleteBank action with the record's ID
    fetchData(); // Refresh the table data
};
  const onSwitch = async (record) => {
    const bankID = setSelectedBank.bankID;
    dispatch(updateBank({ bankID, ...record }));
    dispatch(getBank());
};
  const handleTableChange = (pagination) => {
    const { current, pageSize } = pagination;
    dispatch(setTableData({ pageIndex: current, pageSize: pageSize }));
  };

  const columns = [
    {
      title: <span className="text-gray-500">Action</span>,
      dataIndex: "action",
      fixed: "left",
      width: 100,
      render: (_, record) => (
        <div className="flex items-center">
          <span
            onClick={() => onEdit(record)}
            className="text-2xl text-[#096CAE] cursor-pointer"
          >
            <MdEdit />
          </span>
          <span
            onClick={() => onDelete(record)}
            className="text-2xl ml-2 text-red-500 cursor-pointer"
          >
            <MdDelete />
          </span>
        </div>
      ),
    },
    {
      title: <span className="text-gray-500">Bank Name</span>,
      dataIndex: "name",
    },
    {
      title: <span className="text-gray-500">Short Name</span>,
      dataIndex: "shortName",
    },
    {
      title: <span className="text-gray-500">Contact</span>,
      dataIndex: "contact",
    },
    {
      title: <span className="text-gray-500">Offer</span>,
      dataIndex: "offer",
    },
    {
      title: <span className="text-gray-500">EndDate</span>,
      dataIndex: "endDate",
    },
    {
      title: <span className="text-gray-500">Description</span>,
      dataIndex: "description",
    },
    {
      title: <span className="text-gray-500">Logo</span>,
      dataIndex: "logo",
    },
    {
      title: <span className="text-gray-800">Status</span>,
      dataIndex: "status",
      render: (text, record) => {
        return (
          <Switch
            checked={record.status === 1}  // Ensure it matches your status condition
            onChange={() => onSwitch(record)}
          />
        );
      },
    }
    
  ];

  return (
    <>
      <Table
        className="m-3"
        columns={columns}
        dataSource={data}
        bordered
        onChange={handleTableChange}
        pagination={{
          current: pageIndex,
          pageSize: pageSize,
          showSizeChanger: true,
          pageSizeOptions: [5, 10, 20],
        }}
      />
    </>
  );
};

export default BankTable;
