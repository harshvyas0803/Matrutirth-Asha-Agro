import { combineReducers } from "@reduxjs/toolkit";
import state from "./stateSlice";
import data from "./dataSlice";

const Bankreducer = combineReducers({
    state,
    data,
});

export default Bankreducer;