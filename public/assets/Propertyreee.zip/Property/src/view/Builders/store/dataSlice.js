import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { apiGetBuilder, apiCreateBuilder, apiUpdateBuilder, apiDeleteBuilder, apiUpdateBuilderLogo } from "../../../services/BuildersService";

export const getBuilder = createAsyncThunk("builder/data/getBuilder", async (data) => {
    const response = await apiGetBuilder(data);
    return response.data;
});

export const createBuilder = createAsyncThunk("builder/data/createBuilder", async (data) => {
    const response = await apiCreateBuilder(data);
    return response.data;
});

export const updateBuilder = createAsyncThunk("builder/data/updateBuilder", async (data) => {
    const response = await apiUpdateBuilder(data);
    return response.data;
});

export const deleteBuilder = createAsyncThunk("builder/data/deleteBuilder", async (data) => {
    const response = await apiDeleteBuilder(data);
    return response.data;
});

export const updateBuilderLogo = createAsyncThunk("builder/data/updateBuilderLogo", async (data) => {
    const response = await apiUpdateBuilderLogo(data);
    return response.data;
});



export const initialTableData = {
    total: 0,
    pageIndex: 1,
    pageSize: 10,
    query: "",
    sort: {
        order: "",
        key: "",
    },
};

export const initialFilterData = {
    name: "",
    category: ["bags", "cloths", "devices", "shoes", "watches"],
    status: [0, 1, 2],
    productStatus: 0,
};

const dataSlice = createSlice({
    name: "builderList/data",
    initialState: {
        loading: false,
        builderList: [],
        filterData: initialFilterData,
    },
    reducers: {
        updateProductList: (state, action) => {
            state.branchList = action.payload;
        },
        setTableData: (state, action) => {
            state.tableData = action.payload;
        },
        setFilterData: (state, action) => {
            state.filterData = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(getBuilder.fulfilled, (state, action) => {
                state.loading = false;
                state.builderList = action.payload;
                state.tableData.total = action.payload.count;
            })
            .addCase(getBuilder.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(getBuilder.rejected, (state, action) => {
                state.loading = false;
            })
            .addCase(createBuilder.fulfilled, (state, action) => { })
            .addCase(updateBuilder.fulfilled, (state, action) => { })
            .addCase(updateBuilderLogo.fulfilled, (state, action) => { })
            .addCase(deleteBuilder.fulfilled, (state, action) => { });
    },
});

export const { updateProductList, setTableData, setFilterData } =
    dataSlice.actions;

export default dataSlice.reducer;
