import ApiService from "./ApiService";

export async function apiGetBank(data) {
    return ApiService.fetchData({
        url: "/api/bank/get/list",
        method: "get",
        data,
    });
}

//Dont understand need to change this

export async function apiCreateBank(data) {
    return ApiService.fetchData({
        url: "/api/bank/create",
        method: "post",
        data,
    });
}

export async function apiUpdateBank(data, bankId) {
    return ApiService.fetchData({
        url: "/api/bank/update",
        method: "patch",
        data,
        bankId
    });
}

export async function apiUpdateBankLogo(data) {
    return ApiService.fetchData({
        url: "/api/bank/update/logo",
        method: "patch",
        data,
    });
}

export async function apiDeleteBank(data, bankId) {
    return ApiService.fetchData({
        url: "/api/bank/delete",
        method: "delete",
        data,
        bankId
    });
}


