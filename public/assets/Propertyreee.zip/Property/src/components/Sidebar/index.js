import React, { useEffect, useState } from "react";
import { Menu, Flex } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getMenu } from "./store/dataSlice";
import { HiUserGroup } from "react-icons/hi";
import { CiBank } from "react-icons/ci";
import { injectReducer } from "../../store";
import Menureducer from "./store";
import { FaRegCreditCard } from "react-icons/fa";
import { GiFarmer } from "react-icons/gi";
import { MdOutlineDashboardCustomize, MdOutlineEngineering, MdOutlineRealEstateAgent } from "react-icons/md";
import logo from "../../assets/images/logo/logo1.png";

import * as IoIcons from "react-icons/io";
import * as BsIcons from "react-icons/bs";

import * as GrIcons from "react-icons/gr";
import * as FaIcons from "react-icons/fa";
import * as Fa6Icons from "react-icons/fa6";
import * as RiIcons from "react-icons/ri";
import * as BiIcons from "react-icons/bi";
import * as SiIcons from "react-icons/si";

// import * as Icons from "react-icons/io";

injectReducer("menu", Menureducer);

const Icons = {
  ...IoIcons,
  ...BsIcons,
  ...GrIcons,
  ...FaIcons,
  ...RiIcons,
  ...Fa6Icons,
  ...BiIcons,
  ...SiIcons,
};

export const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedKey, setSelectedKey] = useState(location.pathname);
  const data = useSelector((state) => state.menu.data.menuList.data);
  console.log(data);

  useEffect(() => {
    setSelectedKey(location.pathname);
  }, [location.pathname]);

  const generateMenuItems = (data) => {
    const sortedData = data
      ? [...data].sort((a, b) => a.SEQ_NO - b.SEQ_NO)
      : [];

    return sortedData?.map((item) => {
      let IconComponent = null;
      if (item.icon) {
        IconComponent = Icons[item.icon];
      }
      if (item.children && item.children.length > 0) {
        return {
          key: item.title,
          label: item.title,
          icon: IconComponent ? (
            <IconComponent
              className={`menu-icon ${selectedKey === item.link ? "selected" : ""
                }`}
            />
          ) : null,
          children: generateMenuItems(item.children),
        };
      } else {
        return {
          key: item.link,
          label: item.title,
          icon: IconComponent ? (
            <IconComponent
              className={`menu-icon ${selectedKey === item.link ? "selected" : ""
                }`}
            />
          ) : null,
        };
      }
    });
  };

  return (
    <>
      <Flex
        style={{
          marginLeft: "20px",
        }}
        align=""
      >
        <div className="logo">
          <img src={logo} width={100} alt="" className="" />
        </div>
      </Flex>

      {/* <Menu
        mode="inline"
        className="menu-bar"
        selectedKeys={[selectedKey]}
        // style={{ width: 300 }}
        onClick={(items) => {
          setSelectedKey(items.key);
          navigate(items.key);
        }}
        items={generateMenuItems(data)}
      /> */}
      <Menu

        mode="inline"
        className="menu-bar"
        defaultSelectedKeys={"/farmers"}
        onClick={(items) => {
          navigate(items.key);
        }}
        items={[
          {
            key: "/dashboard",
            icon: <MdOutlineDashboardCustomize />,
            label: "Dashboard",
          },
          // {
          //   key: "/Production",
          //   icon: <GiFarmer />,
          //   label: "Production",
          //   children: [
          //     {
          //       key: "/production",
          //       label: "Production Planning",
          //     },
          //     {
          //       key: "/rawMaterial",
          //       label: "BOM",
          //     },
          //   ],
          // },

          {
            key: "/builders",
            icon: <MdOutlineEngineering />,
            label: "Builders",
          },
          {
            key: "/properties",
            icon: <MdOutlineRealEstateAgent />,
            label: "Properties",
          },
          {
            key: "/bank",
            icon: <CiBank />,
            label: "Bank",
          },
        ]}
      />
    </>
  );
};
