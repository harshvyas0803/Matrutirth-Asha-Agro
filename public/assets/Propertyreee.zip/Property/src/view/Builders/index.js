import React, { useEffect } from 'react'
import { LuPlus } from "react-icons/lu";
import BodyBuilder from './components/BodyBuilder'
import { Button, Modal } from 'antd'
import Builderreducer from './store';
import { injectReducer } from "../../store";
import BuilderForm from './components/BuilderForm';
import { FaUser } from "react-icons/fa";
import { useDispatch, useSelector } from 'react-redux';
import { setSelectedBuilder, toggleNewDialog } from './store/stateSlice';
import { getBuilder } from './store/dataSlice';

injectReducer("builder", Builderreducer);
const Builders = () => {
    const dialog = useSelector((state) => state.builder.state.newDialog);
    const selectedBuilder = useSelector(
        (state) => state.builder.state.selectedBuilder
    );
    const dispatch = useDispatch();
    const onDialog = () => {
        dispatch(setSelectedBuilder(null));
        dispatch(toggleNewDialog(true));
    };
    const handleRefresh = () => {
        dispatch(getBuilder());
    };
    useEffect(() => {
        handleRefresh();
    }, [dispatch]);
    const handleCloseModal = () => {
        dispatch(toggleNewDialog(false)); // Close the modal
    };
    return (
        <>
            <div>
                <div className='flex justify-between text-base h-24 bg-white m-3 p-4 rounded-2xl'>
                    <h1 className='font-bold pt-5'>All Builders</h1>
                    <Button
                        // style={{
                        //     backgroundColor: "#",
                        //     color: "#ffff",
                        //     display: "flex",
                        //     padding: "18px",
                        //     borderRadius: "6px",
                        // }}
                        className='bg-blue-200 p-4 rounded-full mt-4'
                        onClick={onDialog}
                    >
                        <LuPlus />
                        <p>Add Builder</p>
                    </Button>
                </div>
            </div>
            <Modal
                title={
                    <span
                        style={{
                            color: "#096CAE",
                            display: "flex",
                            alignItems: "center",
                        }}
                    >
                        <FaUser className="mr-2" />
                        {selectedBuilder ? "Add or Edit Remarks" : "Add New Builder"}
                    </span>
                }
                open={dialog}
                footer={null}
                style={{ top: "3%" }}
                onCancel={handleCloseModal}
            >
                <BuilderForm handleRefresh={handleRefresh} />
            </Modal>
            <BodyBuilder />
        </>
    )
}

export default Builders

//<button className='bg-blue-200 p-4 rounded-full'>+ Add Builder</button>