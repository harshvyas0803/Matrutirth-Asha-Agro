import axios from "axios";
import BaseService from '../../../services/BaseService';

const phot_url = BaseService.defaults.baseURL;

const UploadImage = async (file, endpoint, label,bankID) => {
    const now = new Date();
    const formattedDate = `${String(now.getFullYear()).slice(-2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}${String(Math.floor(now.getMilliseconds() / 10)).padStart(2, '0')}`;

    const fileExtension = file.name.split('.').pop();
    const newFilename = `${formattedDate}.${fileExtension}`;
    const rawPersistData = localStorage.getItem("token");
    let accessToken = rawPersistData ? rawPersistData : null;
   
    const formData = new FormData();
    formData.append("logo", file, newFilename);
    formData.append("bankID",bankID);

    try {
        const response = await axios.patch(
            `${phot_url}/api/bank/update/logo`,
            formData,
            {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'authorization':  `Bearer ${accessToken}`
                }
            }
        );
       
       
        if (response.status === 200) {
            return newFilename;
        } else {
            throw new Error(response.data.message || 'Upload failed');
        }
    } catch (error) {
        console.error('Error uploading image:', error);
        return false;
    }
};

export default UploadImage;
