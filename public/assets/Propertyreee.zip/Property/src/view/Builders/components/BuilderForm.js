import React, { useEffect, useState } from "react";
import { Formik, Field } from "formik";
import {
    Form,
    Input,
    Row,
    Col,
    Button,
    Select,
    notification,
    Switch,
    Upload,
} from "antd";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { toggleNewDialog } from "../store/stateSlice";
import { DatePicker, Space } from "antd";
import moment from "moment";
import {
    getBuilder, createBuilder, deleteBuilder, updateBuilder, updateBuilderLogo
} from "../store/dataSlice";
import { UploadOutlined } from "@ant-design/icons";


const BuilderForm = () => {
    const [edit, setEdit] = useState(false);
    const [api, contextHolder] = notification.useNotification();
    const dispatch = useDispatch();
    const { Option } = Select;

    const selectedBuilder = useSelector(
        (state) => state.builder.state.selectedBuilder
    );

    const validationSchema = Yup.object({
        name: Yup.string().required("Required"),
        website: Yup.string().required("Required"),
        officeAddress: Yup.string().required("Required"),
        officeContactNumber: Yup.string().required("Required"),
        managerContactNumber: Yup.string().required("Required"),
        salesManagerContactNumber: Yup.string().required("Required"),
        logo: Yup.string(),
    });

    const handleCancel = () => {
        dispatch(toggleNewDialog(false));
    };

    useEffect(() => {
        if (selectedBuilder) {
            setEdit(true);
        } else {
            setEdit(false);
        }
    }, [selectedBuilder]);

    const initialValues = selectedBuilder || {
        name: "",
        website: "",
        officeAddress: "",
        officeContactNumber: "",
        managerContactNumber: "",
        salesManagerContactNumber: "",
        logo: "",
    };
    const handleSubmit = async (values, { setSubmitting }) => {
        console.log(values);
        try {
            const action = edit
                ? await dispatch(updateBuilder(values))
                : await dispatch(createBuilder(values));
            console.log(action);
            if (action.payload.code === 200) {
                dispatch(toggleNewDialog(false));
                dispatch(getBuilder());
                console.log("Form submitted successfully!");
                api.success({
                    message: "Form Submitted Successfully.",
                });
            } else {
                console.error(
                    "Error occurred during form submission:",
                    action.payload.error
                );
            }
        } catch (error) {
            console.error("An unexpected error occurred:", error);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <>
            <div className="mt-4">
                {/* <h2 className="mb-2">Add Distributor</h2> */}
                {contextHolder}
                <Formik
                    enableReinitialize
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={handleSubmit}
                >
                    {({
                        values,
                        touched,
                        errors,
                        isSubmitting,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        setFieldValue,
                    }) => (
                        <Form
                            className=""
                            onFinish={handleSubmit}
                            onFinishFailed={(errorInfo) => {
                                console.error("Failed:", errorInfo);
                            }}
                        >
                            <Row gutter={16}>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={touched.name && errors.name ? errors.name : ""}
                                    // validateStatus={
                                    //   touched.NAME && errors.NAME
                                    //     ? "error"
                                    //     : undefined
                                    // }
                                    >
                                        <span className="text-xs">Builder Name</span>
                                        <Input
                                            name="name"
                                            placeholder="Builder Name"
                                            value={values.name}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.website && errors.website
                                                ? errors.website
                                                : ""
                                        }
                                    // validateStatus={
                                    //   touched.MOBILE_NO && errors.MOBILE_NO
                                    //     ? "error"
                                    //     : undefined
                                    // }
                                    >
                                        <span className="text-xs">Website</span>
                                        <Input
                                            name="website"
                                            placeholder="Website"
                                            value={values.website}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>
                            <Row gutter={16}>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.officeAddress && errors.officeAddress ? errors.officeAddress : ""
                                        }
                                        validateStatus={
                                            touched.officeAddress && errors.officeAddress ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Office Address</span>
                                        <Input
                                            name="officeAddress"
                                            placeholder="Enter Office Address"
                                            value={values.officeAddress}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.officeContactNumber && errors.officeContactNumber ? errors.officeContactNumber : ""
                                        }
                                        validateStatus={
                                            touched.officeContactNumber && errors.officeContactNumber ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Office Contact Number</span>
                                        <Input
                                            name="officeContactNumber"
                                            placeholder="Enter Office Contact Number"
                                            value={values.officeContactNumber}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={touched.managerContactNumber && errors.managerContactNumber ? errors.managerContactNumber : ""}
                                        validateStatus={
                                            touched.managerContactNumber && errors.managerContactNumber ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Manager Contact Number</span>
                                        <Input
                                            name="managerContactNumber"
                                            placeholder="Enter Manager Contact Number"
                                            value={values.managerContactNumber}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={touched.salesManagerContactNumber && errors.salesManagerContactNumber ? errors.salesManagerContactNumber : ""}
                                        validateStatus={
                                            touched.salesManagerContactNumber && errors.salesManagerContactNumber ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Enter Sales Manager Contact Number</span>
                                        <Input
                                            name="salesManagerContactNumber"
                                            placeholder="Enter Sales Manager Contact Number"
                                            value={values.salesManagerContactNumber}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={8}>
                                    <Form.Item
                                        className="flex flex-col"
                                    // help={
                                    //   touched.PROFILE_PHOTO && errors.PROFILE_PHOTO
                                    //     ? errors.PROFILE_PHOTO
                                    //     : ""
                                    // }
                                    // validateStatus={
                                    //   touched.PROFILE_PHOTO && errors.PROFILE_PHOTO
                                    //     ? "error"
                                    //     : undefined
                                    // }
                                    >
                                        <span className="text-xs block">Logo</span>
                                        <Upload
                                            name="logo"
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        >
                                            <Button
                                                style={{ width: "240px", marginTop: "10px" }}
                                                icon={<UploadOutlined />}
                                            >
                                                Click to upload
                                            </Button>
                                        </Upload>
                                    </Form.Item>
                                </Col>

                            </Row>
                            <Row gutter={16}>
                                <Col span={24}>
                                    <Form.Item className="flex justify-end">
                                        <Button
                                            onClick={handleCancel}
                                            type="primary"
                                            className="mr-4"
                                        >
                                            Cancel
                                        </Button>
                                        <Button
                                            type="primary"
                                            htmlType="submit"
                                            disabled={isSubmitting}
                                        >
                                            {edit ? "Update" : "Save"}
                                        </Button>
                                    </Form.Item>
                                </Col>

                            </Row>
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    );
};

export default BuilderForm;
