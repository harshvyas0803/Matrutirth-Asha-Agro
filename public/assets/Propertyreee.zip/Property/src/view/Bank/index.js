import React, { useEffect } from 'react'
import { LuPlus } from "react-icons/lu";
import { Button, Modal } from 'antd'
import Bankreducer from './store';
import { injectReducer } from "../../store";
import { FaUser } from "react-icons/fa";
import { useDispatch, useSelector } from 'react-redux';
import { setSelectedBank, toggleNewDialog } from './store/stateSlice';
import { getBank } from './store/dataSlice';
import BankTable from './components/BankTable';
import FormBank from './components/FormBank';


injectReducer("bank", Bankreducer);
const Bank = () => {
    const dialog = useSelector((state) => state.bank.state.newDialog);
    const selectedBank = useSelector(
        (state) => state.bank.state.selectedBank
    );
    const dispatch = useDispatch();
    const onDialog = () => {
        dispatch(setSelectedBank(null));
        dispatch(toggleNewDialog(true));
    };
    const handleRefresh = () => {
        dispatch(getBank());
    };
    useEffect(() => {
        handleRefresh();
    }, [dispatch]);
    const handleCloseModal = () => {
        dispatch(toggleNewDialog(false)); // Close the modal
    };
    return (
        <>
            <div>
                <div className='flex justify-between text-base h-24 bg-white m-3 p-4 rounded-2xl'>
                    <h1 className='font-bold pt-5'>All Bank Details</h1>
                    <Button
                        // style={{
                        //     backgroundColor: "#",
                        //     color: "#ffff",
                        //     display: "flex",
                        //     padding: "18px",
                        //     borderRadius: "6px",
                        // }}
                        className='bg-blue-200 p-4 rounded-full mt-4'
                        onClick={onDialog}
                    >
                        <LuPlus />
                        <p>Add Bank Form</p>
                    </Button>
                </div>
            </div>
            <Modal
                title={
                    <span
                        style={{
                            color: "#096CAE",
                            display: "flex",
                            alignItems: "center",
                        }}
                    >
                        <FaUser className="mr-2" />
                        {selectedBank ? "Add or Edit Remarks" : "Add New Bank"}
                    </span>
                }
                open={dialog}
                footer={null}
                style={{ top: "3%" }}
                onCancel={handleCloseModal}
            >
                <FormBank handleRefresh={handleRefresh} />
            </Modal>
            <BankTable handleRefresh={handleRefresh} />
        
            
        </>
    )
}

export default Bank;

//<button className='bg-blue-200 p-4 rounded-full'>+ Add Builder</button>