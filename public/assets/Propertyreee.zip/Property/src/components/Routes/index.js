import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";

import Dashboard from "../../view/Dashboard";
import Builders from "../../view/Builders";
import Properties from "../../view/Properties";
import Bank from "../../view/Bank";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/builders" element={<Builders />} />
      <Route path="/properties" element={<Properties />} />
      <Route path="/bank" element={<Bank />} />
      <Route path="/*" element={<Navigate to="/dashboard" />} />
    </Routes>
  );
};

export default AppRoutes;
