import ApiService from "./ApiService";

export async function apiGetBuilder(data) {
    return ApiService.fetchData({
        url: "/api/builder/get",
        method: "get",
        data,
    });
}

//Dont understand need to change this

export async function apiCreateBuilder(data) {
    return ApiService.fetchData({
        url: "/api/builder/create",
        method: "post",
        data,
    });
}

export async function apiUpdateBuilder(data) {
    return ApiService.fetchData({
        url: "/api/builder/update",
        method: "patch",
        data,
    });
}

export async function apiUpdateBuilderLogo(data) {
    return ApiService.fetchData({
        url: "/api/builder/update/logo",
        method: "patch",
        data,
    });
}

export async function apiDeleteBuilder(data) {
    return ApiService.fetchData({
        url: "/api/builder/delete",
        method: "delete",
        data,
    });
}


