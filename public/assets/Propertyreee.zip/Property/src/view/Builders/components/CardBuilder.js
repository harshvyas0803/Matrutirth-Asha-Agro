import React from 'react'
import { MdEdit } from 'react-icons/md'
import { RxCross2 } from "react-icons/rx";
const CardBuilder = () => {
    return (
        <div className='bg-white p-4 rounded-xl'>
            <div className='flex'>
                <img src="https://images.pexels.com/photos/1043473/pexels-photo-1043473.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="card img" className='w-16 h-24 object-cover' />
                <div className='ml-4 items-center pt-5'>
                    <div className='font-bold pr-3 text-[19px] text-[#1D1662]'>Card Title</div>

                    <div className='text-[14px] text-[#1D1662]'>Card Subtitle</div>
                </div>
                <div className='ml-auto flex gap-1'>
                    <MdEdit className='bg-[#7000FF] p-1 rounded-full' color='white' size={20} />
                    <RxCross2 className='bg-[#FF6524] p-1 rounded-full' color='white' size={20} />

                </div>
            </div>
            <p className='mt-4 mb-8 text-[16px] text-[#1D1662]'>lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit,  sed diam non suscipit auctor ut pulvinar risus.
            </p>
            <div className='my-3 text-[14px] font-normal text-gray-600'>Email: rintughosh1aa@gmail.com</div>
            <div className='my-3 text-[14px] font-normal text-gray-600'>Phone: 8145960038</div>
            <div className='my-3 text-[14px] font-normal text-gray-600'>Location: India</div>
        </div>
    )
}

export default CardBuilder