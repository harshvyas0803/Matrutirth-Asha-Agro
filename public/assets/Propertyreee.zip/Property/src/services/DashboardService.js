import ApiService from "./ApiService";

export async function apiGetCustomerCount(data) {
    return ApiService.fetchData({
        url: "/api/report/getCount",
        method: "post",
        data,
    });
}
export async function apiGetTodaysCustomerCount(data) {
    return ApiService.fetchData({
        url: "/api/report/getTodaysCustomerCount",
        method: "post",
        data,
    });
}
export async function apiGetMonthCustomerCount(data) {
    return ApiService.fetchData({
        url: "/api/report/getMonthCustomerCount",
        method: "post",
        data,
    });
}
export async function apiGetCustomerOffer(data) {
    return ApiService.fetchData({
        url: "/api/report/getCountOffer",
        method: "post",
        data,
    });
}
export async function apiGetDobDoaCount(data) {
    return ApiService.fetchData({
        url: "/api/report/get31DaysCount",
        method: "post",
        data,
    });
}
export async function apiGetCustomerChart(data) {
    return ApiService.fetchData({
        url: "/api/report/getCustomerReport",
        method: "post",
        data,
    });
}
