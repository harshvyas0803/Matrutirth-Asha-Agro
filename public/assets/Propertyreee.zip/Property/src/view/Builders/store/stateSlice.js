import { createSlice } from "@reduxjs/toolkit";

const stateSlice = createSlice({
    name: "builderList/state",
    initialState: {
        deleteConfirmation: false,
        selectedBuilder: "",
        newDialog: false,
        filterDialog: false,
    },
    reducers: {
        toggleDeleteConfirmation: (state, action) => {
            state.deleteConfirmation = action.payload;
        },
        setSelectedBuilder: (state, action) => {
            state.selectedBuilder = action.payload;
        },
        toggleNewDialog: (state, action) => {
            state.newDialog = action.payload;
        },
        toggleFilterDialog: (state, action) => {
            state.filterDialog = action.payload;
        },
    },
});

export const {
    toggleDeleteConfirmation,
    setSelectedBuilder,
    toggleNewDialog,
    toggleFilterDialog,
} = stateSlice.actions;

export default stateSlice.reducer;
