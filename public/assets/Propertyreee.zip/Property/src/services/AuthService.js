import ApiService from "./ApiService";

export async function apiLogin(data) {
    return ApiService.fetchData({
        url: "/api/admin/login/phoneAndPassword",
        method: "post",
        data,
        headers: {
            "Content-Type": "application/json",

        },
    });
}


