import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
    apiGetBank,
    apiCreateBank,
    apiUpdateBank,
    apiDeleteBank,
    apiUpdateBankLogo,
} from "../../../services/BankService";

export const getBank = createAsyncThunk("bank/data/getBank", async (data) => {
    const response = await apiGetBank(data);
    return response.data;
});

export const createBank = createAsyncThunk("bank/data/createBank", async (data) => {
    const response = await apiCreateBank(data);
    return response.data;
});

export const updateBank = createAsyncThunk("bank/data/updateBank", async (data) => {
    const response = await apiUpdateBank(data);
    return response.data;
});

export const deleteBank = createAsyncThunk("bank/data/deleteBank", async (data) => {
    const response = await apiDeleteBank(data);
    return response.data;
});

export const updateBankLogo = createAsyncThunk("bank/data/updateBankLogo", async (data) => {
    const response = await apiUpdateBankLogo(data);
    return response.data;
});

export const initialTableData = {
    total: 0,
    pageIndex: 1,
    pageSize: 10,
    query: "",
    sort: {
        order: "",
        key: "",
    },
};

export const initialFilterData = {
    name: "",
    category: ["bags", "cloths", "devices", "shoes", "watches"],
    status: [0, 1, 2],
    productStatus: 0,
};

const dataSlice = createSlice({
    name: "bankList/data",
    initialState: {
        loading: false,
        bankList: [],
        filterData: initialFilterData,
        tableData: initialTableData, // Initialize tableData here
    },
    reducers: {
        updateProductList: (state, action) => {
            state.branchList = action.payload;
        },
        setTableData: (state, action) => {
            state.tableData = action.payload;
        },
        setFilterData: (state, action) => {
            state.filterData = action.payload;
        },
    },
    extraReducers: (bank) => {
        bank
            .addCase(getBank.fulfilled, (state, action) => {
                state.loading = false;
                state.bankList = action.payload;
                if (!state.tableData) {
                    state.tableData = { ...initialTableData }; // Ensure tableData is initialized
                }
                state.tableData.total = action.payload.count; // Set the total value
            })
            .addCase(getBank.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(getBank.rejected, (state, action) => {
                state.loading = false;
            })
            .addCase(createBank.fulfilled, (state, action) => {})
            .addCase(updateBank.fulfilled, (state, action) => {})
            .addCase(updateBankLogo.fulfilled, (state, action) => {})
            .addCase(deleteBank.fulfilled, (state, action) => {});
    },
});

export const { updateProductList, setTableData, setFilterData } =
    dataSlice.actions;

export default dataSlice.reducer;
