import React, { useEffect, useState } from "react";
import { Formik, Field } from "formik";
import {
    Form,
    Input,
    Row,
    Col,
    Button,
    Select,
    notification,
    Switch,
    Upload,
} from "antd";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { toggleNewDialog } from "../store/stateSlice";
import {
    getBank, createBank, updateBank,
} from "../store/dataSlice";
import { UploadOutlined } from "@ant-design/icons";
import UploadImage from "./UploadImage";

const FormBank = () => {
    const [edit, setEdit] = useState(false);
    const [api, contextHolder] = notification.useNotification();
    const dispatch = useDispatch();
    const { Option } = Select;

    const selectedBank = useSelector((state) => state.bank.state.selectedBank);

    const validationSchema = Yup.object({
        name: Yup.string().required("Required"),
        shortName: Yup.string().required("Required"),
        contact: Yup.string().required("Required"),
        offer: Yup.string().required("Required"),
        endDate: Yup.string().required("Required"),
        description: Yup.string().required("Required"),
        logo: Yup.string(),
    });

    const handleCancel = () => {
        dispatch(toggleNewDialog(false));
    };

    useEffect(() => {
        if (selectedBank) {
            setEdit(true);
        } else {
            setEdit(false);
        }
    }, [selectedBank]);

    const initialValues = selectedBank || {
        name: "",
        shortName: "",
        contact: "",
        offer: "",
        endDate: "",
        description: "",
        logo: "",
        bankID: "_id",
    };

    const handleSubmit = async (values, { setSubmitting }) => {
        console.log(values);
        try {
            const action = edit
                ? await dispatch(updateBank(values))
                : await dispatch(createBank(values));

            if (action.payload.message === "Bank Created" || action.payload.message === "Bank Updated") {
                dispatch(toggleNewDialog(false));
                dispatch(getBank());
                api.success({
                    message: "Form Submitted Successfully.",
                });
            } else {
                console.error("Error occurred during form submission:", action.payload.error);
            }
        } catch (error) {
            console.error("An unexpected error occurred:", error);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <>
            <div className="mt-4">
                {contextHolder}
                <Formik
                    enableReinitialize
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={handleSubmit}
                >
                    {({
                        values,
                        touched,
                        errors,
                        isSubmitting,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        setFieldValue,
                    }) => (
                        <Form
                            className=""
                            onFinish={handleSubmit}
                            onFinishFailed={(errorInfo) => {
                                console.error("Failed:", errorInfo);
                            }}
                        >
                            <Row gutter={16}>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={touched.name && errors.name ? errors.name : ""}
                                    >
                                        <span className="text-xs">Bank Name</span>
                                        <Input
                                            name="name"
                                            placeholder="Bank Name"
                                            value={values.name}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.shortName && errors.shortName
                                                ? errors.shortName
                                                : ""
                                        }
                                    >
                                        <span className="text-xs">Short Name</span>
                                        <Input
                                            name="shortName"
                                            placeholder="Short Name"
                                            value={values.shortName}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>

                            <Row gutter={16}>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.contact && errors.contact ? errors.contact : ""
                                        }
                                        validateStatus={
                                            touched.contact && errors.contact ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Contact</span>
                                        <Input
                                            name="contact"
                                            placeholder="Contact"
                                            value={values.contact}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.offer && errors.offer ? errors.offer : ""
                                        }
                                        validateStatus={
                                            touched.offer && errors.offer ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Offer</span>
                                        <Input
                                            name="offer"
                                            placeholder="Offer"
                                            value={values.offer}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.endDate && errors.endDate ? errors.endDate : ""
                                        }
                                        validateStatus={
                                            touched.endDate && errors.endDate ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">End Date</span>
                                        <Input
                                            name="endDate"
                                            placeholder="End Date"
                                            value={values.endDate}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={
                                            touched.description && errors.description ? errors.description : ""
                                        }
                                        validateStatus={
                                            touched.description && errors.description ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">Description</span>
                                        <Input
                                            name="description"
                                            placeholder="Enter description"
                                            value={values.description}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        />
                                    </Form.Item>
                                </Col>
                            </Row>

                            <Row gutter={16}>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                    >
                                        <span className="text-xs block">Profile Photo</span>
                                        <Upload
                                            name="logo"
                                            customRequest={({ file, onSuccess }) => {
                                                UploadImage(
                                                    file,
                                                    "your-upload-endpoint",
                                                    "logo"
                                                ).then((newFilename) => {
                                                    if (newFilename) {
                                                        onSuccess("ok");
                                                        setFieldValue("logo", newFilename); // Save the new filename in form values
                                                    }
                                                });
                                            }}
                                            listType="picture"
                                            className="!rounded"
                                            style={{ padding: "8px" }}
                                        >
                                            <Button
                                                style={{ width: "240px", marginTop: "10px" }}
                                                icon={<UploadOutlined />}
                                            >
                                                Click to upload
                                            </Button>
                                        </Upload>
                                    </Form.Item>
                                </Col>
                            </Row>

                            <Row gutter={16}>
                                <Col span={12}>
                                    <Form.Item
                                        className="flex flex-col"
                                        help={touched.STATUS && errors.STATUS ? errors.STATUS : ""}
                                        validateStatus={
                                            touched.STATUS && errors.STATUS ? "error" : undefined
                                        }
                                    >
                                        <span className="text-xs">STATUS</span>
                                        <div className="flex items-center">
                                            <Switch
                                                name="STATUS"
                                                checked={values.STATUS}
                                                onChange={(checked) => {
                                                    setFieldValue("STATUS", checked);
                                                }}
                                                onBlur={handleBlur}
                                                className="!rounded-full custom-switch"
                                                style={{ padding: "8px 5px" }}
                                            />
                                        </div>
                                    </Form.Item>
                                </Col>
                            </Row>

                            <Row gutter={16}>
                                <Col span={24}>
                                    <Form.Item className="flex justify-end">
                                        <Button
                                            onClick={handleCancel}
                                            type="primary"
                                            className="mr-4"
                                        >
                                            Cancel
                                        </Button>
                                        <Button
                                            type="primary"
                                            htmlType="submit"
                                            disabled={isSubmitting}
                                        >
                                            {edit ? "Update" : "Save"}
                                        </Button>
                                    </Form.Item>
                                </Col>
                            </Row>
                        </Form>
                    )}
                </Formik>
            </div>
        </>
    );
};

export default FormBank;
